#!/bin/bash

####################################################################
####	Copyright Brandon Kruse <bkruse@digium.com> && Digium	####
####################################################################

# Quick script for applying zaptel settings from the GUI.

ZAPCONF="/etc/zaptel.conf"
ZAPATACONF="/etc/asterisk/zapata.conf"
ZTCFG_OUTPUT="/var/lib/asterisk/static-http/config/ztcfg_output.html"
FILENAME="/etc/asterisk/applyzap.conf"
grep -v "\[general\]" ${FILENAME} | grep -v "\;" > ${ZAPCONF} 
cp -rf ${ZAPCONF} ${ZAPCONF}.zapscan # save the gui settings!
cp -rf ${ZAPATACONF} ${ZAPATACONF}.zapscan # save the user settings
zapscan
ztcfg -vv > ${ZTCFG_OUTPUT}
